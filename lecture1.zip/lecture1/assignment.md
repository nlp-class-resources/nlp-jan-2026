# Improve the rule based classifier

- Improve the rule based classifier by adding more features 
- Experiment with feature weights and explain the results.
- Add lemmatization ,stemming.

Bonus points for using regex to extract features.